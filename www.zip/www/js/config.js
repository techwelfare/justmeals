
var krms_config ={			
	'ApiUrl':"http://justmeals.co.uk/merchantapp/api",	
	'DialogDefaultTitle':"Just Meals Store",
	'pushNotificationSenderid':"1052081260274"
};